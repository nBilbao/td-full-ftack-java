package com.busesChile.models;

import java.util.ArrayList;

public class Cliente {

    private String nombre;
    private String apellido;
    private String rut;
    private ArrayList<Pasaje> pasajeReservas;
    private Integer edad;


}
