package com.nbilbao.productsAndCategory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductsAndCategoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
