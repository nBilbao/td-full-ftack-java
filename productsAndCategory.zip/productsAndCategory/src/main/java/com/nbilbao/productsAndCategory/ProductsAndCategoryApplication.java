package com.nbilbao.productsAndCategory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductsAndCategoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductsAndCategoryApplication.class, args);
	}

}
